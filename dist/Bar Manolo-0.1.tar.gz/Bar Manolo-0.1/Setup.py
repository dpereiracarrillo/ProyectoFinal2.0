from distutils.core import setup

setup(name="Bar Manolo",
      version="0.1",
      description="Es un bar",
      author="Daniel Pereira",
      author_email="dpereiracarrillo@danielcastelao.org",
      url="http://ehhhhhhh.com",
      license="GPL",
      scripts=["Inicio.py","Bar.py","ReportLab.py"],


      )